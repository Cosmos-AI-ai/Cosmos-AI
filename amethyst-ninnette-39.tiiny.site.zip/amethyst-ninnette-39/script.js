const cells = document.querySelectorAll('.cell');
const resetButton = document.getElementById('reset-button');
const messageElement = document.getElementById('message');

let currentPlayer;
let board = Array(9).fill(null);
let isGameActive = true;

// Winning combinations
const winningCombinations = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6],
];

// Function to start the game
function startGame() {
    board = Array(9).fill(null);
    isGameActive = true;
    currentPlayer = Math.random() > 0.5 ? 'X' : 'O'; // Randomly decide who starts
    updateMessage();
    cells.forEach(cell => {
        cell.classList.remove('You', 'Cosmos', 'win');
        cell.textContent = '';
    });

    // If Cosmos starts, make its move immediately
    if (currentPlayer === 'O') {
        cosmosMove();
    }
}

// Update the message with the current player
function updateMessage() {
    if (!isGameActive) return;
    messageElement.textContent = currentPlayer === 'X' ? 'Your Turn (X)' : 'Cosmos\' Turn (O)';
}

// Handle user click
function handleClick(event) {
    const cell = event.target;
    const index = cell.getAttribute('data-index');

    if (board[index] || !isGameActive || currentPlayer !== 'X') return;

    // Player move
    board[index] = 'X';
    cell.classList.add('You');
    cell.textContent = 'X';

    if (checkWin()) {
        highlightWinningCells();
        messageElement.textContent = `You (X) Wins!`;
        messageElement.classList.add('win');
        isGameActive = false;
    } else if (board.every(cell => cell)) {
        messageElement.textContent = 'Draw!';
        messageElement.classList.add('draw');
        isGameActive = false;
    } else {
        currentPlayer = 'O';
        updateMessage();
        cosmosMove();
    }
}

// Minimax algorithm to choose the best move
function minimax(board, depth, isMaximizing) {
    const winner = checkWinner();
    if (winner === 'O') return 10 - depth;
    if (winner === 'X') return depth - 10;
    if (board.every(cell => cell)) return 0;

    if (isMaximizing) {
        let bestScore = -Infinity;
        for (let i = 0; i < board.length; i++) {
            if (!board[i]) {
                board[i] = 'O';
                const score = minimax(board, depth + 1, false);
                board[i] = null;
                bestScore = Math.max(score, bestScore);
            }
        }
        return bestScore;
    } else {
        let bestScore = Infinity;
        for (let i = 0; i < board.length; i++) {
            if (!board[i]) {
                board[i] = 'X';
                const score = minimax(board, depth + 1, true);
                board[i] = null;
                bestScore = Math.min(score, bestScore);
            }
        }
        return bestScore;
    }
}

// Choose the best move for Cosmos
function cosmosMove() {
    let bestMove;
    let bestScore = -Infinity;
    for (let i = 0; i < board.length; i++) {
        if (!board[i]) {
            board[i] = 'O';
            const score = minimax(board, 0, false);
            board[i] = null;
            if (score > bestScore) {
                bestScore = score;
                bestMove = i;
            }
        }
    }

    if (bestMove !== undefined) {
        board[bestMove] = 'O';
        cells[bestMove].classList.add('Cosmos');
        cells[bestMove].textContent = 'O';

        if (checkWin()) {
            highlightWinningCells();
            messageElement.textContent = `Cosmos (O) Wins!`;
            messageElement.classList.add('win');
            isGameActive = false;
        } else if (board.every(cell => cell)) {
            messageElement.textContent = 'Draw!';
            messageElement.classList.add('draw');
            isGameActive = false;
        } else {
            currentPlayer = 'X';
            updateMessage();
        }
    }
}

// Check for a winner
function checkWinner() {
    for (const [a, b, c] of winningCombinations) {
        if (board[a] && board[a] === board[b] && board[a] === board[c]) {
            return board[a];
        }
    }
    return null;
}

function checkWin() {
    const winner = checkWinner();
    return winner === 'X' || winner === 'O';
}

// Highlight the winning cells
function highlightWinningCells() {
    const winner = checkWinner();
    if (winner) {
        winningCombinations.forEach(combination => {
            if (combination.every(index => board[index] === winner)) {
                combination.forEach(index => cells[index].classList.add('win'));
            }
        });
    }
}

// Reset the game
function resetGame() {
    startGame();
}

cells.forEach(cell => cell.addEventListener('click', handleClick));
resetButton.addEventListener('click', resetGame);

// Start the game on page load
startGame();
